$(function() {

	$("#form_caixa").validate({
		rules : {
			caixatipo : {
				required : true
			}
		}
	});
});