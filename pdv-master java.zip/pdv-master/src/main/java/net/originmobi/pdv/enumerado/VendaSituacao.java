package net.originmobi.pdv.enumerado;

public enum VendaSituacao {
	ABERTA, FECHADA, CANCELADA;

}
