package net.originmobi.pdv.filter;

public class ReceberFilter {

	String cliente;

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

}
