package net.originmobi.pdv.enumerado.cartao;

public enum CartaoTipo {
	DEBITO, CREDITO;
}
