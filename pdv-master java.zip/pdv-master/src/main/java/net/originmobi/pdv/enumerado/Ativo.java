package net.originmobi.pdv.enumerado;

public enum Ativo {
	ATIVO, INATIVO
}
