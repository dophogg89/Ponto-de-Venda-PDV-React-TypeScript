package net.originmobi.pdv.enumerado.caixa;

public enum EstiloLancamento {
	ENTRADA, SAIDA;
}
