package net.originmobi.pdv.repository.notafiscal;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.NotaFiscalFinalidade;

public interface NotaFiscalFinalidadeRepository extends JpaRepository<NotaFiscalFinalidade, Long> {

}
