package net.originmobi.pdv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.CstCsosn;

public interface CstCsosnRepository extends JpaRepository<CstCsosn, Long>{

}
