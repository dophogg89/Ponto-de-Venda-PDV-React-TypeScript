package net.originmobi.pdv.filter;

public class AjusteFilter {

	private Long codigo;

	public Long getCodigo() {
		return codigo;
	}

	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}

}
