package net.originmobi.pdv.filter;

public class BancoFilter {
	
	private String data_cadastro;

	public String getData_cadastro() {
		return data_cadastro;
	}

	public void setData_cadastro(String data_cadastro) {
		this.data_cadastro = data_cadastro;
	}
}
