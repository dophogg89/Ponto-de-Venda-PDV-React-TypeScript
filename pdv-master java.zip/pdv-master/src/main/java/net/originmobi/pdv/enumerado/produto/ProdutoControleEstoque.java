package net.originmobi.pdv.enumerado.produto;

public enum ProdutoControleEstoque {
	SIM, NAO;
}
