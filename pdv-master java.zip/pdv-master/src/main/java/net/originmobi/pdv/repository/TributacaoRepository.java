package net.originmobi.pdv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.Tributacao;

public interface TributacaoRepository extends JpaRepository<Tributacao, Long> {

}
