package net.originmobi.pdv.enumerado;

public enum TituloTipo {
	DIN, CARTDEB, CARTCRED;
}
