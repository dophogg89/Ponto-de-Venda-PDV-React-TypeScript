package net.originmobi.pdv.enumerado;

public enum TelefoneTipo {
	FIXO, CELULAR;
}
