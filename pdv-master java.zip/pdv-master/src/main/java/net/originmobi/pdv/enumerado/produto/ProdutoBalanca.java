package net.originmobi.pdv.enumerado.produto;

public enum ProdutoBalanca {

	NAO, SIM;
}
