package net.originmobi.pdv.enumerado.caixa;

public enum TipoLancamento {
	SUPRIMENTO, SANGRIA, SALDOINICIAL, RECEBIMENTO, TRANSFERENCIA, PAGAMENTO;
}
