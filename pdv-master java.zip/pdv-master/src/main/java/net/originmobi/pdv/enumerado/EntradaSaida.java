package net.originmobi.pdv.enumerado;

public enum EntradaSaida {
	ENTRADA, SAIDA
}
