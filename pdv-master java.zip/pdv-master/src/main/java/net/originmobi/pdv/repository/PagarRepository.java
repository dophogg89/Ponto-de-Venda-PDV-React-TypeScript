package net.originmobi.pdv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.Pagar;

public interface PagarRepository extends JpaRepository<Pagar, Long> {

}
