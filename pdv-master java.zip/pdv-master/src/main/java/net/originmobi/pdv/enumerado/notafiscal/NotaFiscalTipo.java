package net.originmobi.pdv.enumerado.notafiscal;

public enum NotaFiscalTipo {
	ENTRADA, SAIDA;
}
