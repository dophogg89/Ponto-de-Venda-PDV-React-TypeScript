package net.originmobi.pdv.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.PagarTipo;

public interface PagarTipoRepository extends JpaRepository<PagarTipo, Long> {

}
