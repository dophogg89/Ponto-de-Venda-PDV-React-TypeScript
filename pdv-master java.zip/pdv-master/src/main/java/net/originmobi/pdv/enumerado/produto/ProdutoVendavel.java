package net.originmobi.pdv.enumerado.produto;

public enum ProdutoVendavel {
	SIM, NAO;
}
