package net.originmobi.pdv.enumerado;

public enum PessoaTipo {
	
	FISICA, JURIDICA;

}
