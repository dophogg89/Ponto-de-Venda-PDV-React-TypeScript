package net.originmobi.pdv.repository.notafiscal;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.CstIPI;

public interface CstIpiRepository extends JpaRepository<CstIPI, Long>{

}
