package net.originmobi.pdv.enumerado.caixa;

public enum CaixaTipo {
	
	CAIXA, COFRE, BANCO;

}
