package net.originmobi.pdv.enumerado;

public enum EnumeradoTitulos {
	DIN, DEB, CRED; 
}
