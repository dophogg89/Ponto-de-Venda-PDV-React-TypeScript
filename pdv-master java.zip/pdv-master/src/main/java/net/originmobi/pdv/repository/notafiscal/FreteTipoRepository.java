package net.originmobi.pdv.repository.notafiscal;

import org.springframework.data.jpa.repository.JpaRepository;

import net.originmobi.pdv.model.FreteTipo;

public interface FreteTipoRepository extends JpaRepository<FreteTipo, Long> {

}
